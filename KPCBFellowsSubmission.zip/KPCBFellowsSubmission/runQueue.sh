#!/bin/sh

javac BoundedQueue.java
java BoundedQueue