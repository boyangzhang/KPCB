BoundedQueue.java
-------------

Methods
--------
BoundedQueue(int length) - constructor
isEmpty() - check if queue is empty
isFull() - check if queue is full
enqueue(int n) - enqueues a value
dequeue() - dequeues a value

How to run
-----------
./runQueue.sh

Compiles and runs the basic test main